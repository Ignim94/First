package com.example.web.model;

public enum RoleType {
	USER,ADMIN // role에 넣을 타입을 강제하는것 USER나 ADMIN만 작성되게 하는거
	// 남,녀를 넣거나 뭐 그럴때 활용하면 좋음
;

	int length() {
		// TODO Auto-generated method stub
		return 0;
	}

}
