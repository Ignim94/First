package com.example.web.Controller;

import org.springframework.stereotype.Controller;

@Controller
public class BoardController {

}
